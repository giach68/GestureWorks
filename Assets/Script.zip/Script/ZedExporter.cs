﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Diagnostics;
using System.Threading;
// SDK di ZED
using sl;

public class ZedExporter : MonoBehaviour
{
    Process exporterProcess;
    ProcessStartInfo startInfo;
    string exporterPath = @"C:\Program Files (x86)\ZED SDK\samples\bin\ZED_SVO_Export.exe";
    string pathSVO = "path/to/file.svo";
    string pathOutput = "path/to/output/file.avi";
    int mod = 3; //LEFT+DEPTH_VIEW image sequence.

    public void runExporter()
    {
        /*
        string videoOut;
        var txtFiles = Directory.EnumerateFiles("VideoSVO", " *.svo", SearchOption.AllDirectories);
        foreach(string video in txtFiles)
        {
            
            videoOut = video.Replace("VideoSVO", "VideoFrame");
            if (File.Exists(videoOut))
                continue;
            try
            {
                using (Process myProcess = new Process())
                {
                    myProcess.StartInfo.UseShellExecute = false;
                    // You can start any process, HelloWorld is a do-nothing example.
                    myProcess.StartInfo.FileName = exporterPath;
                    myProcess.StartInfo.CreateNoWindow = true;
                    myProcess.StartInfo.Arguments = video + " " + videoOut + " " + mod.ToString();
                    myProcess.Start();
                    // This code assumes the process you are starting will terminate itself. 
                    // Given that is is started without a window so you cannot terminate it 
                    // on the desktop, it must terminate itself or you can do it programmatically
                    // from this application using the Kill method.
                    myProcess.WaitForExit();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    */    
    }
    
}
