﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Threading;
using System.Diagnostics;
// SDK di ZED
using sl;

public class ZedRecorderThread : MonoBehaviour
{
    //camera's variables
    private ZEDManager zedManager;
    private Thread _thread_recorder;

    //File where to save video .svo
    [Header("Recording")]
    [Tooltip("{fileName}_{MM_dd_h_mm}.svo")]
    public string fileName="action";
    [Tooltip("Nome cartella")]
    public string subject="sub1";
    public sl.SVO_COMPRESSION_MODE svoCompressionMode = sl.SVO_COMPRESSION_MODE.AVCHD_BASED;
    [Tooltip("in secondi")]
    public double frameInterval = 0.4; // in secondi
    //public bool needRecordFrame = false;
    private bool isRecording = false;

    private int fi;
    private Stopwatch stopWatch = new Stopwatch();
    private string fileSaved;
    private static AutoResetEvent restart = new AutoResetEvent(false);


    // Start is called before the first frame update
    void Start()
    {
        // Get istance of the ZEDCamera
        zedManager = ZEDManager.GetInstance(ZED_CAMERA_ID.CAMERA_ID_01);
        OnEnable();
        _thread_recorder = new Thread(Recorder);
        _thread_recorder.Start();
    }

    /// <summary>
    /// Fixes GI, enables the canvas and subscribes to events from the ZED. 
    /// </summary>
    private void OnEnable()
    {
        zedManager.OnZEDReady += ZEDReady;
        zedManager.OnZEDDisconnected += ZEDDisconnected;
    }

    /// <summary>
    /// Configures numerous settings that can't be set until the ZED is fully initialized. 
    /// Subscribed to ZEDManager.OnZEDReady in OnEnable(). 
    /// </summary>
    private void ZEDReady()
    {
        UnityEngine.Debug.Log("Inizializzazione camera");

        while (!zedManager.zedCamera.IsCameraReady)
        {
            Thread.Sleep(1000);
            UnityEngine.Debug.Log("Tentativo fallito. Ritento.");
        }

        UnityEngine.Debug.Log("Tutto pronto");
    }

    void Update()
    {
        if (Input.GetKeyDown("space"))
        {
            print("space key was pressed");
            if (isRecording)
            {
                // disattiva thread
                isRecording = false;
            }
            else // attiva thread
            {
                restart.Set();
            }

        }
    }

    /// <summary>
    /// Thread function to record camera video
    /// </summary>
    void Recorder()
    {
        int fi;
        try
        {
            do
            {
                // wait start signal
                restart.WaitOne();
                isRecording = true;

                UnityEngine.Debug.Log("Inizio cattura video");
                fi = (int)(frameInterval * 1000);
                //isRecording = true;
                Directory.CreateDirectory(string.Format("VideoSVO/{0}", subject));
                sl.ERROR_CODE svoerror = zedManager.zedCamera.EnableRecording(string.Format("VideoSVO/{0}/{1}_{2}.svo", subject, fileName, System.DateTime.Now.ToString("MM_dd_h_mm")),
                                                                              svoCompressionMode);
                if (svoerror == sl.ERROR_CODE.SVO_RECORDING_ERROR)
                {
                    UnityEngine.Debug.LogError("SVO recording failed. Check that there is enough space on the drive and that the "
                        + "path provided is valid.");
                }
                else if (svoerror != sl.ERROR_CODE.SUCCESS)
                {
                    UnityEngine.Debug.LogError("Error code in EnableRecording: " + svoerror.ToString());
                }
                else // recording loop
                {
                    while (isRecording)
                    {
                        zedManager.zedCamera.Record();
                        Thread.Sleep(fi);
                    }
                    UnityEngine.Debug.Log("Termine cattura video");
                }
            } while (true);
        }
        catch (ThreadAbortException abortException)
        {
            //Permette l'interruzione della thread attraverso abort()
            UnityEngine.Debug.Log((string)abortException.ExceptionState);
        }
        catch (IOException e)
        {
            UnityEngine.Debug.Log((string)e.ToString());
        }
        finally
        {
            zedManager.zedCamera.DisableRecording();
            isRecording = false;
            UnityEngine.Debug.Log("Fine cattura video");
        }

    }

    /// <summary>
    /// Disables the canvas and unsubscribes from events from the ZED. 
    /// </summary>
    public void Close()
    {
        zedManager.OnZEDReady -= ZEDReady;
        zedManager.OnZEDDisconnected -= ZEDDisconnected;
        _thread_recorder.Abort();
    }

    private void ZEDDisconnected()
    {
        return;
    }

}
