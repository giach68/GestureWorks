﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class logger : MonoBehaviour
{
    public string name;
    public string basepath = "C:\\logs";
    public string path;
    private string buffer;

    void OnEnable()
    {
        path = basepath + "\\" + name + "_" + System.DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss") + ".txt";
        if (!File.Exists(path))
            File.WriteAllText(path, "% Hand Tracking log file " + System.DateTime.Now.ToString() + "\n%");
    }

    // Update is called once per frame
    void Update()
    {
        if (buffer != "")
        {
            File.AppendAllText(path, buffer);
            buffer = "";
        }
    }

    public void writeData(string text)
    {
        buffer += text;
        File.AppendAllText(path, buffer);
        buffer = "";
    }

    public void newLine(string text)
    {
        buffer += "\n" + text;
        return;
    }
    public void addToLine(string text)
    {
        buffer += text;
        return;
    }
    public void newLineMarked(string text)
    {
        buffer += "\n%" + text;
        return;
    }
    public void closeLine()
    {
        buffer += "\n";
        return;
    }
    public string getTimeStamp()
    {
        return System.DateTime.Now.ToString("HH-mm-ss");
    }

}
