﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Diagnostics;
using System.Threading;
// SDK di ZED
using sl;

public class ZedRecorder : MonoBehaviour
{
    //camera's variables
    private ZEDManager zedManager;

    //File where to save video .svo
    [Header("Recording")]
    [Tooltip("{fileName}_{MM_dd_h_mm}.svo")]
    public string fileName="action";
    [Tooltip("Nome cartella")]
    public string subject="sub1";
    public sl.SVO_COMPRESSION_MODE svoCompressionMode = sl.SVO_COMPRESSION_MODE.AVCHD_BASED;
    [Tooltip("in secondi")]
    public double frameInterval = 0.4; // in secondi
    //public bool needRecordFrame = false;
    public bool isRecording = false;

    private int fi;
    private Stopwatch stopWatch = new Stopwatch();
    private string fileSaved;

    // Start is called before the first frame update
    void Start()
    {
        // Get istance of the ZEDCamera
        zedManager = ZEDManager.GetInstance(ZED_CAMERA_ID.CAMERA_ID_01);
        OnEnable();
    }

    /// <summary>
    /// Fixes GI, enables the canvas and subscribes to events from the ZED. 
    /// </summary>
    private void OnEnable()
    {
        zedManager.OnZEDReady += ZEDReady;
        zedManager.OnZEDDisconnected += ZEDDisconnected;
    }

    /// <summary>
    /// Configures numerous settings that can't be set until the ZED is fully initialized. 
    /// Subscribed to ZEDManager.OnZEDReady in OnEnable(). 
    /// </summary>
    private void ZEDReady()
    {
        UnityEngine.Debug.Log("Inizializzazione camera");

        while (!zedManager.zedCamera.IsCameraReady)
        {
            Thread.Sleep(1000);
            UnityEngine.Debug.Log("Tentativo fallito. Ritento.");
        }

        UnityEngine.Debug.Log("Tutto pronto");
    }

    void Update()
    {
        // No thread //
        if (Input.GetKeyDown("space"))
        {
            print("space key was pressed");
            if (isRecording)
            {
                // disattiva recording
                stopWatch.Stop();
                zedManager.zedCamera.DisableRecording();
                isRecording = false;
                UnityEngine.Debug.Log("Fine cattura video");
                UnityEngine.Debug.Log("Video salvato in : " + fileSaved);
            }
            else // attiva recording
            {
                UnityEngine.Debug.Log("Inizio cattura video");
                fi = (int)(frameInterval * 1000);
                Directory.CreateDirectory(string.Format("VideoSVO/{0}", subject));
                fileSaved = string.Format("VideoSVO/{0}/{1}_{2}.svo", subject, fileName, System.DateTime.Now.ToString("MM_dd_h_mmss"));
                sl.ERROR_CODE svoerror = zedManager.zedCamera.EnableRecording(fileSaved, svoCompressionMode);
                // conrollo errori
                if (svoerror == sl.ERROR_CODE.SVO_RECORDING_ERROR)
                {
                    UnityEngine.Debug.LogError("SVO recording failed. Check that there is enough space on the drive and that the "
                        + "path provided is valid.");
                }
                else if (svoerror != sl.ERROR_CODE.SUCCESS)
                {
                    UnityEngine.Debug.LogError("Error code in EnableRecording: " + svoerror.ToString());
                }
                else
                {
                    isRecording = true;
                    zedManager.zedCamera.Record();
                    stopWatch.Restart();
                }
            }
        }
        // recording loop
        if (isRecording && (int)stopWatch.ElapsedMilliseconds >= fi)
        {
            zedManager.zedCamera.Record();
            stopWatch.Restart();
        }

    }

    /// <summary>
    /// Disables the canvas and unsubscribes from events from the ZED. 
    /// </summary>
    public void Close()
    {
        zedManager.OnZEDReady -= ZEDReady;
        zedManager.OnZEDDisconnected -= ZEDDisconnected;
    }

    private void ZEDDisconnected()
    {
        return;
    }

}
