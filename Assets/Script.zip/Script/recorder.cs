﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap.Unity;

public class recorder : MonoBehaviour
{
    public float timer;
    bool recording;

    // Start is called before the first frame update
    void Start()
    {
        recording = false;
    }

    // Update is called once per frame
    void Update()
    {
        //Space for start recording
        if (Input.GetKey(KeyCode.Space) && !recording)
        {
            Record();
        }

        //Alt for stop recording
        if (Input.GetKey(KeyCode.LeftAlt) && recording)
        {
            Stop();

        }
    }

    public void Record()
    {
        if (!recording)
            StartCoroutine(Wait());
        else
            Stop();
    }

    public void Stop()
    {
        string msg = "Not Recording";
        GameObject leapRig = GameObject.Find("Leap Rig");
        posTracker pt = leapRig.GetComponent<posTracker>();
        recording = false;
        Debug.Log(msg);
        pt.enabled = recording;
    }

    IEnumerator Wait()
    {
        string msg = "The recording will start in " + timer + " seconds";
        recording = true;
        Debug.Log(msg);
        yield return new WaitForSeconds(timer);
        GameObject leapRig = GameObject.Find("Leap Rig");
        posTracker pt = leapRig.GetComponent<posTracker>();
        Debug.Log("Recording");
        pt.enabled = recording;
    }
}
